<?php get_header(); ?>
<?php
get_template_part(
    'components/heros/home-hero',
    null,
    [
        'heading' => 'Joey McQuillan',
        'body' => 'Designer and Web Developer'
    ]
);
get_template_part('components/recent-works');
?>
<?php get_footer();
