<section class="hero">
  <h1><?php echo $args['heading'] ?>
  </h1>
  <p><?php echo $args['body'] ?>
  </p>
</section>