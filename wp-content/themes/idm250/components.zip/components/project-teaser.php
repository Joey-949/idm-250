<div class="project-teaser">
  <?php the_post_thumbnail(); ?>
  <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
  <p><?php the_excerpt(); ?>
  </p>
</div>