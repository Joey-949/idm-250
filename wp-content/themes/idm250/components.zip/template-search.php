<?php
/* Template Name: Search */
 get_header(); ?>

<?php get_footer();
