
<footer class="footer ">
  <p class="container">&copy; <?php echo date('Y'); ?> | Joey McQuillan
  </p>
</footer>
<?php
  wp_footer();
?>
</body>

</html>